import Results from "./components/Results";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Shop from "./components/Shop";
import Footer from "./components/Footer";
import CoverPage from "./components/CoverPage";
import Login from "./components/LoginForm";
import OrderConfirm from "./components/OrderConfirm";
import AddToCart from "./components/AddToCart";
import MyOrders from "./components/MyOrders";
import AboutUs from "./components/AboutUs";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Router>
        <CoverPage />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/results" element={<Results />} />
          <Route path="/OrderConfirm" element={<OrderConfirm />} />
          <Route path="/AddToCart" element={<AddToCart />} />
          <Route path="/MyOrders" element={<MyOrders />} />
          <Route path="/AboutUs" element={<AboutUs />} />
        </Routes>
        <Footer />
      </Router>
    </div>
  );
}

export default App;
