import React, { useState } from "react";
import styled from "styled-components";
import ButtonNice from "./Button";
import "./Form.css";
function Form() {
  const [Dropper, setDropper] = useState(false);
  const [TextInput, setTextInput] = useState("");
  return (
    <Container>
      <FormArea>
        <Heading>
          Choose Your Vender{" "}
          <QuestionMark className="QuestionMark">?</QuestionMark>
        </Heading>
        <SearchDrop>
          <Input>
            <input
              className="SearchBox"
              type="text"
              onChange={(e) => {
                setDropper(true);
                setTextInput(e.target.value);
              }}
              value={TextInput}
              placeholder="Enter the item"
            />
          </Input>
          <DropElement>
            <Display>
              <Mover dropper={Dropper} onClick={() => setDropper(false)}>
                <Option
                  onClick={() => setTextInput("Edible Oil")}
                  className="a"
                >
                  Edible Oil
                </Option>
                <Option
                  onClick={() => setTextInput("Edible Oil")}
                  className="b"
                >
                  Edible Oil
                </Option>
                <Option
                  onClick={() => setTextInput("Edible Oil")}
                  className="c"
                >
                  Edible Oil
                </Option>
                <Option
                  onClick={() => setTextInput("Edible Oil")}
                  className="d"
                >
                  Body Oil
                </Option>
                <Option
                  onClick={() => setTextInput("Edible Oil")}
                  className="e"
                >
                  Oregano
                </Option>
              </Mover>
            </Display>
          </DropElement>
        </SearchDrop>
        <Button>
          <a href="/results">
            <ButtonNice />
          </a>
        </Button>
      </FormArea>
    </Container>
  );
}

export default Form;
const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 100px 0;
`;
const FormArea = styled.div`
  background-color: white;
  width: 650px;
  height: 400px;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
  border-radius: 20px;
`;
const Heading = styled.div`
  font-size: 30px;
  display: flex;
  position: relative;
  top: 40px;
  font-weight: 500;
`;
const QuestionMark = styled.div`
  font-size: 100px;
  position: relative;
  top: -50px;
  left: 10px;
`;

const SearchDrop = styled.div`
  position: relative;
  top: -82px;
  z-index: 2;
`;
const Button = styled.div`
  z-index: 1;
`;
const DropElement = styled.div`
  position: absolute;
  top: -158px;
  height: 265px;
  width: 310px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;
const Mover = styled.div`
  height: 100%;
  position: relative;
  top: -200px;
  width: 100%;
  transition: 500ms;
  display: flex;
  align-items: center;
  flex-direction: column;
  transform: ${(props) =>
    props.dropper ? "translateY(100%)" : "translateY(0%)"};
`;
const Display = styled.div`
  position: relative;
  top: 202px;
  height: 50%;
  width: 100%;
  overflow: hidden;
`;
const Input = styled.div`
  position: relative;
  z-index: 1000;
`;
const Option = styled.div`
  width: 90%;
  height: 30px;
  padding: 5px;
  //   border-radius: 10px;
  //   border: 1px solid;
  text-align: center;
  cursor: pointer;
`;
