import React, { useState, useEffect } from "react";
import "./OrderConfirm.css";
import styled from "styled-components";
import Navbar from "./Navbar";
function OrderConfirm() {
  const [status, setStatus] = useState("Order Confirmed");
  const [lastUpdate, setLastUpdate] = useState(new Date().toLocaleString());
  const [fluidHeight, setFluidHeight] = useState(0);

  const maxFluidHeight = 100;
  const fillRate = 50;

  const updateStatus = () => {
    let newStatus;
    if (status === "Order Confirmed") newStatus = "Shipped";
    else if (status === "Shipped") newStatus = "Out for Delivery";
    else if (status === "Out for Delivery") newStatus = "Delivered";
    else newStatus = "Order Confirmed";

    setStatus(newStatus);
    setLastUpdate(new Date().toLocaleString());
  };

  useEffect(() => {
    if (fluidHeight < maxFluidHeight) {
      setFluidHeight((prevHeight) => prevHeight + fillRate / 10);
    }
  }, [fluidHeight]); // Start the animation when fluidHeight changes

  return (
    <Container>
      <Navbar />
      <div className="order-container">
        <h1>Order Details</h1>
        <div className="order-inside">
          <div className="order2">
            <div className="gola"></div>
            <p>
              <strong>Quantity:</strong> 5
            </p>
            <p>
              <strong>Order Number:</strong> <span id="orderNumber">23681</span>
            </p>
            <p id="updateDate">Last Updated: {lastUpdate}</p>
            <button onClick={updateStatus} className="buttonn">
              Update Status
            </button>

            <p>
              <strong>Status:</strong> <span id="orderStatus">{status}</span>
            </p>
            <p>
              <strong>Total Amount:</strong> Rs{" "}
              <span id="totalAmount">1242</span>
            </p>
            <button id="markAsDeliveredBtn" className="buttonn">
              Return Policy
            </button>
          </div>
          <div className="statusrow">
            <div className="fluid" style={{ height: `${fluidHeight}px` }}></div>
            <div className="updateStatus">Order-confirmed</div>
          </div>
        </div>
      </div>
    </Container>
  );
}

export default OrderConfirm;
const Container = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
`;
