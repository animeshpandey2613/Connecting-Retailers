import React from "react";
import "./Footer.css";
import Image from "../images/logo.png";
function Footer() {
  return (
    <div>
      <div class="footer">
        <ul class="footer__nav">
          <li class="footer__item">
            <a class="footer__link" href="#">
              About
            </a>
          </li>
          <li class="footer__item">
            <a class="footer__link" href="#">
              Pricing
            </a>
          </li>
          <li class="footer__item">
            <a class="footer__link" href="#">
              Terms of Use
            </a>
          </li>
          <li class="footer__item">
            <a class="footer__link" href="#">
              Privacy Policy
            </a>
          </li>
          <li class="footer__item">
            <a class="footer__link" href="#">
              Careers
            </a>
          </li>
          <li class="footer__item">
            <a class="footer__link" href="#">
              Blog
            </a>
          </li>
          <li class="footer__item">
            <a class="footer__link" href="#">
              Contact Us
            </a>
          </li>
        </ul>
        <img src={Image} alt="Logo" class="footer__logo" />
        <p class="footer__copyright">
          &copy; Copyright by Retail Rosters.pvt.ltd
          <a class="footer__link twitter-link" target="_blank" href=""></a>
        </p>
      </div>
    </div>
  );
}

export default Footer;
