import React from "react";
import NavBar from "./Navbar";
import styled from "styled-components";
import OrderButton from "./OrderButton";
function AddToCart() {
  const data = [
    {
      Name: "Fortune Oil",
      Price: "140",
      Image:
        "https://www.bigbasket.com/media/uploads/p/l/272765_9-fortune-soya-bean-oil.jpg",
      Quantity: "1L",
      Pieces: "10",
      Number: "4",
    },
    {
      Name: "Prestige Oil",
      Price: "625",
      Image: "https://m.media-amazon.com/images/I/61m8vWwgieL.jpg",
      Quantity: "5L",
      Pieces: "1",
      Number: "1",
    },
  ];
  return (
    <div>
      <NavBar />
      <Parent>
        <Container>
          <Heading>Place Order</Heading>
          <Products>
            {data.map((ele) => {
              return (
                <Cards>
                  <Image>
                    <img src={ele.Image} />
                  </Image>
                  <Information>
                    <Name>Name :{ele.Name}</Name>
                    <Price>Price :{ele.Price}</Price>
                    <Quantity>Quantity :{ele.Quantity}</Quantity>
                    <Pieces>Peices :{ele.Pieces}</Pieces>
                  </Information>
                  <ItemNumber>Items :{ele.Number}</ItemNumber>
                </Cards>
              );
            })}
          </Products>
          <Bill>
            <Order1>Fortune Oil : 140x4 : 560 Rs</Order1>
            <Order2>Prestige Oil : 625x1 : 625 Rs</Order2>
            <GST>GST (%8) : 92 Rs</GST>
            <Shipping>Shipping : 150 Rs</Shipping>
            <Discount>Discount(10%): 185 </Discount>
            <Total> TOTAL : 1,242</Total>
          </Bill>
          <Button>
            <OrderButton />
          </Button>
        </Container>
      </Parent>
    </div>
  );
}

export default AddToCart;
const Container = styled.div`
  background-color: #edf5e1;
  width: 80vw;
  height: 80vh;
  border-radius: 40px;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
`;
const Parent = styled.div`
  display: flex;
  justify-content: center;
  height: 100vh;
  align-items: center;
`;

const Heading = styled.div`
  font-size: 35px;
  font-weight: 500;
  color: #05386b;
`;
const Products = styled.div`
  display: flex;
  justify-content: space-around;
  width: 1100px;
`;
const Cards = styled.div`
  height: 200px;
  width: 500px;
  background-color: #5cdb95;
  border-radius: 30px;
  display: flex;
  align-items: center;
  &:hover {
    background-color: #379683;
  }
`;

const Image = styled.div`
  margin-left: 30px;
  height: 60%;
  width: 100px;
  img {
    width: 100%;
    height: 100%;
    border-radius: 10px;
  }
`;
const Information = styled.div`
  margin-left: 20px;
  width: 200px;
`;
const ItemNumber = styled.div`
  margin-left: 40px;
  background-color: #edf5e1;
  padding: 10px;
  border-radius: 10px;
  cursor: pointer;
`;

const Bill = styled.div`
  display: flex;
  flex-direction: column;
  border: 1px solid;
  padding: 20px;
  border-radius: 10px;
`;
const Order1 = styled.div``;
const Order2 = styled.div``;
const Shipping = styled.div``;
const Discount = styled.div``;
const GST = styled.div``;
const Total = styled.div`
  font-size: 20px;
  margin-left: 30px;
  margin-top: 10px;
  font-weight: 500;
`;

const Button = styled.div``;

const Name = styled.div``;
const Price = styled.div``;
const Quantity = styled.div``;
const Pieces = styled.div``;
