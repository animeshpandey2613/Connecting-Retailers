import React from "react";
import Navbar from "./Navbar";
import ItemBank from "./ItemBank";
import Footer from "./Footer";

function Results() {
  return (
    <div>
      <Navbar />
      <ItemBank />
    </div>
  );
}

export default Results;
