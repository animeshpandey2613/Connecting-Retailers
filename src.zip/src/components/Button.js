import React from "react";
import "./Button.css";
import "@alphardex/aqua.css/dist/aqua.min.css"; // Import Aqua.css from the installed package

function Button() {
  return (
    <button type="submit" className="btn btn-primary btn-ghost">
      Search
    </button>
  );
}

export default Button;
