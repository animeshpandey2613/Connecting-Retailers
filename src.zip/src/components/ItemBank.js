import React from "react";
import styled from "styled-components";
import "./ItemBank.css";
import Counter from "./Counter";
function ItemBank() {
  const data = [
    {
      Name: "Surbhi Supplier",
      Item: {
        EdibleOil: [
          {
            Name: "Fortune Oil",
            Price: "140",
            Image:
              "https://www.bigbasket.com/media/uploads/p/l/272765_9-fortune-soya-bean-oil.jpg",
            Quantity: "1L",
            Pieces: "10",
            Expiry: [25, 9, 2024],
          },
          {
            Name: "Fortune Oil",
            Price: "700",
            Image:
              "https://www.bigbasket.com/media/uploads/p/l/274148_14-fortune-sun-lite-sunflower-refined-oil.jpg",
            Quantity: "5L",
            Pieces: "1",
            Expiry: [13, 9, 2028],
          },
          {
            Name: "Prestige Oil",
            Price: "150",
            Image:
              "https://www.jiomart.com/images/product/original/491397873/prestige-refined-soybean-oil-1-l-product-images-o491397873-p590323772-0-202208221807.jpg?im=Resize=(420,420)",
            Quantity: "1.2L",
            Pieces: "10",
            Expiry: [18, 9, 2025],
          },
          {
            Name: "Prestige Oil",
            Price: "625",
            Image: "https://m.media-amazon.com/images/I/61m8vWwgieL.jpg",
            Quantity: "5L",
            Pieces: "1",
            Expiry: [23, 11, 2023],
          },
          {
            Name: "Krati Oil",
            Price: "625",
            Image:
              "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSERUSExIQFREVGRYXFhcSEBAVExYYFhgXFhcSFRUYHighGBonGxYVITEhJSkrLi4uGB8zODYtNygtLisBCgoKDg0OGhAQGjcmHyUtLS0tLS0tKy0tLTErLS0tLS0tLS8vLS8tLS0tLS0tLS0tLS0tLy0tLS0tLS8tKy0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABgcDBAUCAQj/xABGEAABAwICBAkGDQMDBQAAAAABAAIDBBESIQUxQVEGEyJTYXGRktIUFzKBodEHFSMkQlJUYpOxweHwcoKyNEOiFnPC4vH/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAwQFAgEG/8QANREAAgECAwUGBAUFAQAAAAAAAAECAxEEIVESFDFBkRMVImFxoQWB0fAjMrHB4UJSYpLxM//aAAwDAQACEQMRAD8AtdERcF4IiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAii/wgVkkUEZjkcwmUAlji0kYXm2XSAuPSaYmrJ4IIppGMZG3jHCQte8hrRIb6yb5DtUUqqUtm2nuX6OAnUpKrtJRzu88rfXRZlgIolS8NozIIeJkvjEYOMO+la5Jz6dq4NTpuTi6ksnqMTCwNL5DZt5CCG21ardS8daPLM6h8MrN2ktnhx83bkWWirmfTsgpqZ75KtjnGQYmyEGWxYcRJ1jlWHUVYccYBLrm7rXuSRkNg2LuE1LgQYjCyoJOXNyX+rseURFGZ5lREU5MEREAREQBERAEREAREQBERAEREAREQBERAEREBFfhEgfJTRtY1zjxtyGBzjbC8XsOsKP6Q0SaFlLWQ3xAMMt75PIxnLYCMTP7RvVlLXrqRk0bopG4mO1i5Go3BBGo3AN1DOjduXM0cN8QlSjGm14U3fzTya+XFEL+DiMmeaUscGuALHOaQLOfchrtR2aty5EGiZnsrAI5LmzgCx4JAkztcZ5G+SsSl0WyGIRQuexgJI5TnEX1i7jqubr22jfcfLymxvY4LHo1al52HhSfn7kkvibVac4Ryeza/wDi011sV1pemkfR0TRFNjjMocOKfcHEDmLarOVoN1BY6aNzQQXufne7rXHRlsWVdwhs89PYrYnFuvGMbWs5P/Z39jEiIuDNMqIinJgiIgCIiAIiIAiLy9wAudS8bsD0i15ayNouXt7c1qHT9ODYyAdYK47WH9yB00WKmqWSDExwcN4KyrtNPgehEQlengRYXVTB9ILIyQO1EHqK5jOMuD90enpERdHgREQBERAEREAREQGJERQEJlREU5MEREAREQBERAFp6UxcWcLcRGdr2W4sN8T7bG6+tQ12lBrXIES0iyqLLinbbpc6+zZ6lDK6Oa/KiI6r2/matbS9TlZROozKypPZdkWISurtHR+D6B4hkc4EBzhhz+qDc+0KVqF00TQ3NzmjXyXuGfqK72j4H2uXkM18pxvZW6OKUYqOyRyXM6t+wa1w9M6UsLN/dfa2vxcluTR7ekqL6RqsTzuCrYnEupkuB7Cnndnp9Wb+kVkp9IPBuHG4XnROjnTkhuzWTqC2KrQ74CMVi06i29uo7iqqhPZ27Zak7twJXouuEzMX0hk4dO9bqh2iKnipAfonJ3vUxW1ha3awz4rj9fmVpx2WERFZOAiIgCIiAIiwVdS2Njnu1NF+vcB0k5IepXdkekUX+P5ubZ/yRU+1iS7jW8upLURFcIQiIgCIiAIiIDxPLhaXbgtWmkwxFx1nNY9NSclrfrH2D97LT0vUYWBo3LPxNTx20X6/wdWuc7SFbclcKaqzXqrnWzwd0SZ34nD5Np7x2NCz85OyLGSV2dbg3o0vtLJ6OtoO37x6Fs6U0njOFvoD/l0pprSAA4llrD0iOj6I6Fxi5dyaitlfMjirvaZ9nqbAlR0z3K6ta7kFcFqhZPFFi8CmfNy7a5x9gH7rs1lOJGFp26ug7CuPwMPzb+536LvLcoRToxT4WKs34mQuaK3WpNoeoxxNO0ZH1Lk6VitI7rv25rZ4OvsXt6iszCSdOu6fqun/AAkqZxudtERbRAEREAREQBR7hLUYpIoBt5b+oZNH+XYFIVBZ6vHUzSbGktb1N5I/K/rUdR5FzBQvU2tF78EdPk9CKN/GPSiqXJ92epZaIivmYEREAREQBERAcPS8nyzRuA9ua4+m6i5W5pWT5cnco7pKe5WJiJ+OXqTwWSPFJTOnkDG7dZ3DaSphWTNpYWxsycRZu8A63npK19BUjaeEyP8ASIu7fb6MY/Mrj19YXuMjzr/gAXK/Dj5v2D8UrckeS7avIctaOF0hzDjfU1tz7BrWw+lwGxY5h3EOb7Co0SGKr9EriALv1DNYK5BhzXjzOosm3AiT5J7dzge0fspIopwKYeURmLWcNo2td1awpWtrCv8ABiVZ/mZztIQguJ+5fsK1NEC0xG9n6hb1bILu6Ggesm60dEZzOO5tu0qhJLe01qe38J3ERFrkYREQBERAYaybBG9/1Wud2AlVhDPaNx2kqw+Eb7Usx+7btIH6qqKme0dulQ1Ga3w2Hhk/Nexh8qRcnj19VWxc2T9CIiLQPnQiIgCIiAIiICG6cktK/rK5+hKbjJcbhdrTkN7tgW1wjHyzhvP5rZoSIYsW0ZN6XnWfUsOovxHfUsJ+Eadq7niwcm5uO923sXJ0fSPqJWtaL58kbOl56FjqnXOG+bsyehWFwT0SIYg9w+UeAelrdjf1P7LqjSdepZ8OZzUmqULmekoW0kJLGcZJlciwc4kgazqaL36htK+YRWUxxxGMnFhDi0uaQSGvBGw2B6jmurUQte0tcAWnWD0G/wCi+wQNYMLQANwW4oRUNm2RmNy2tq+ZVE5uBvGR9S1zHddrhTQGGd2XIkJe3dnm5vqP5hchjl89Ui4TcWa0JKUUzYoHOjcHMcWu3g+w7wu/DpKUjNw68IuuAx9lsGuDRqXsaso8HYONzoTzZa1v6AZk52/8v5dRyhqDNK1mppNjbWptFGGlwaLAGw6gLKxg6e1Pb0+hHUdrR+ZlREWsRBERAEREBx+Fx+Zy9Tf8gqbrpb2AVycLm3o5epv+QVS0EOKXFb0dX9WxQVVmbXwy3Zt+f7I1PiObcilfkh+v7UVe532si0kRFfMIIiIAiIgCIiAiHCCP5wfUfYFqV0upg1NHt2rqcJHWlH9IPZcKMVMuTjtWLiLRqS9SxDNHW4JUHlFTc+g3lH+lpsG+s29V1aCivwfUmGndJte6w/pZl+eJdPhFWcVTPkxuYRbNrGPOsDCGuyz1Z6rrSwkFTo7T55/T2KdVOrWUI6pLj+ybOutWtr4orcZLEy+rjHtbfquq++P64Pe1z5g1kYldaCmxtYbcojVazutar64iplqDUPdhiicHeTwuc4PDMLAx3JZbEbkbjvXbxC5Lr/00KfweTfjkrW/pu7ttJK9suP0TLDnggq4rYmSMOp0bmmx3tcNRUJ0rwUmiJLQZWbHMHLHW33XW3wMil8sqg8uY7C3E3DCLudYtdZnJBAvq14s1NZKcF2O5DrWyI2XO3rUdWmq0L7Ofrb9n0ZUrR3WrsRldWT6pP9+K4rMqQSEZf/V4nkyVgcItHxyvwvDQ4jJ7QA5u7Fb0m7wfUoFVU7mOcxw5TCQfVu6Fi1EozlFO+y7PVaZefL6ponpVFNXsZ+DbrTN6wrAjPpdZVaaMkwvB6VYej5cQPqPaP2WjgZK2z98DisvFc20RFpEQREQBERAc7hCzFSzD7hPZn+iqih5ALzrGY6zqVv6RAMMgOoseD3SqXrJ7jrzUNQ1/hjupL0PnlR3ntRc/Eiq3LR+gkRFoHzwREQBERAEReJn4Wk7gT2BAQbT9XimedgOEdQyXGldkOsL3Uy3cTvJWB7tXWvn5y25N6luKtYtzguAKSENIPJF7bCcyD6ytnS9AyoidE++F+6wIINwRfbcBRTQ1cYmMIcAC1osduV7W9SksOlmkcprh1Z/uruF+J0Jx2J+F8M+Dtlk+HydtORRnSqU57cdbp8/tEO0NoiSWSYy+UMaYuLIcDxxa0s5JeYwwghtsiT+a3YNC00zntwVcYkjYzlhga3isGGzs7uyGu981LmVUb8gQb5WIIvvGYWs7RtMyxMULbaiWMFtXhHYr0IU9m/HzJavxGvKe1B7PkvK3lfkrGpR6Hja+WQTvfJK1jHkujuDGAMQwgWdlcrpzSiJgvcnUNpK0Y2QRkvhhjDiLY2sDBmbnlWzz3XWvO8vNyb9JuBbcBsHtKq4vGwowtB5vhw5+vH9NdHVtOpPanxsl8krJHuvlbJhcNuveCFDOEA+cX2uZn1gFv5AKVNHVfLUopwkf84P3Y8+xx/UL5unVlUxLnLi1nb0S/VX+bL9ONrI4FO7lKxtEjkMP1m29Y/hVawnlKzNFf6aI7nW7clu4Hi/L6nmIyaN9ERaxCEREAREQHD4aVnFUUp2vAjH9+R/44lTU0lyrI+FSptFDH9ZznH+0AD/IqsHOVeq8ze+GwtSvq/4GNFhuigsSn6OREV8+cCIiAIiIAtPSzrQSH7p9uS3Fo6d/08nV+oXE/wAr9GelaSOzWF7l6e5YnL59oukk0RptjQ1krcm6nWuMtRI2KTUekmvtYOs7Icl19usbBkMzvUAomh4I/malEVa4NycbnETyQByseV7nIYm93pKgUKCU9teJ8M1Zc78Vzy5+hTrU67mthpR53u23pwaS53bWb48TvxxTXFxSYcr2E1+m3tX2KOoA1UjT91s2qxy177Z9ai0fGAZSPH9xXx003OP7VS27Z2LbpSfJdCTOnla9vGGms475i+wGdr5bs16n0hEHYcYxWJsCLm369Cg9c25aZXygA+mwuLm9ItmsM0Mb2uF5HPY4EE4g8tIJ4zfry9at0qKqRU7a3tb2538udjidO2bysuSJRVafJB4ttwLco52B1dSjNRUF5kkcbk2H89TV8grQI34BMHOaG4gWmPD9VwI1681rTmzGjabuP5D9e1d06ailK921n9+lvQ8oypzV4Zow03pKztGi1JH/AFD81WdA27grQhbanibvI/NamDVlL0IsS+BtoiLVIwiIgCIiArT4WZflIW7mX7XH3KvSVOvhXPzln/bH+TlAiq8/zH0eB/8ACP3zPmNFjuvqhsD9KIiK8fOBERAEREAWlpht4JR9wnsz/Rbq8ysxNLd4I7RZeNXVgVA/WvBKyTCziDrBIKxOWA0XrmWknwOvs29SklHM12pwPrz7FFQ5ew5m0H1Ee5QVKKmeqVibL6QoTyPvexAGfe7Aod0/y9v5Ou08iQaRjlwDE90kbdTGBrXWzzLttlimrHQvLY5ZeONrMLWOY0HMB78WWs+1cUBm93YPevQDN57o96uwls5z8T6EMoRlJStw/c7GktIGZwjB5Dc3EZNcRrcANmvtXHqpcTiezoGwLJJUgNwtFgdZJu53QTsHQtW65ebO1kdPQ8d3hWS//abuF+wKB8HY7vCnVO/E8nY0Bv8AOxaWFXhtq/5KlbOaNtERaBwEREAREQFZfC3FaWF29hHdd/7KvCrV+FmnvBDJ9V5af723/wDBVZZQz4m/gJXoryv+prIvdl9UB1c/SaIiunzwREQBERAF8c4DMkDrNl9XxzAciAR0gFAVVwxg4mpcW2dHIS9paQQCc3NNtRvf1WXDNWrqdQRHXFEeuNnuWM6Kg5iD8KP3KrLCxk73O1UaRSxrBvXjy0b1dJ0NTfZ6f8GP3Lz8R0v2an/Bj9y43KOp72svu5THlw3r15cN4Vy/ENL9lp/wI/cvnxBS/Zab8CP3JuUdR2svu5TYrhvC9itG8K4fiGl+y034EfuXr4ipfs1N+DH7k3KGo7WX3cpw1Y3pHUK4/iOm+zU/4MfuXoaHpvs9P+DH7k3GOo7WWn6lc6Fr8J6VYWh5GCJvLZidyjy23udmvdZZxouAf7EH4UfuWRlHGNUcY6mNH6KenRUOBG22Z0RFMAiIgCIiA4XDKmZPSSw44xJbEwOe1vKacQGeq9retUTJIQbEEEbwv0i6Np1taesArwaWPm4+433LlxTLFDEzpXS4H5r49F+jfI4+bj/DZ7kUFkeb9PT3NxERWSAIiIAiIgCIiAIi5em617DBHGWNfPJxeN7S5rAGPkPJuMTiGYQL6zfO1iDOotDTuLyWfBix8VLhwXxYsDrYbZ3va1lzKbTr8MbMDppnzPhPyfk+AtYZbva4u1Mtcg5nUNiyR8I7m/FHinOnZG/jGlzn0+PGHMtyAeLfY3OoXAuhzdNGgNHyxMh5AJe8YsBqJCGiCbN3GE4DiIFxbXbctCimq4ozhdU4uJorNfC4tjYWRsmew8W75RpDrt5RFyS02Xdl4SgejEXOw0ZA4xouax7o2i9ssJbcnbdeWcJHPDWsg+WPlWJpmaGs8kkEMpDyOXyi22QuDnhXtzmy1NOOsry0uFnOZBM9reJcBNIHyNhY5z2sLSWhhcABc5iwK8QaSqsDS6SURGWxlZSyPma3isQaYzC0WMmWIMNvRJvms9JwofghLoi+8VE+WQPa2xqzxYLY7Z2eLkXGRy1WW6eEF28iPlnywNDn5XpXFmdhqcbHoXh7lqZuCweKSHGHB+E4g5rmuviOtpzHUusuQ3Sj20JqnxgyNhdMY43F2LCwvDWm20AZbL2ztdajdIzxujEkkEomilkHFRlhYY2h+Jt3Oxx8oC52luu+Q9vYkSLjaE0i+V7g48kQ0sgyAN5WyF17f0hdlDpO4REQBERAEREAREQGJERQEJlRVv5wajmoe7L4k84NRzUPdl8SbxA2u58VouqLIRVv5wajmoe7L4k84NRzUPdl8SbxAdz4rRdUWQirfzg1HNQ92XxJ5wajmoe7L4k3iA7nxWi6oshFW/nBqOah7sviTzg1HNQ92XxJvEB3PitF1RZCw1dKyVpZIxj2G12vaHDLMGx2gqvfODUc1D3ZfEnnBqOah7svjTeIDufFaLqifU+joYw0MijaGEuaGsaMLnAhzhbaQSCdtyvkejYWyOlbFEJXXxPDG4je17npsL77BQLzg1HNQ92XxJ5wajmoe7L4k3iA7nxWi6onNNoWmjFo6eFguw2bGwC8RxRnIfRJJG7Yvc2iYHgNdDC4BzngOjaQHvJL36tbi4k77lQPzg1HNQ92XxJ5wajmoe7L4k3iB53Nif7V1RPho2G1uKjtaNtsDbWhOKIdTTmNy8x6LgbI6UQxCV18TwxuI4rB1ztvYX32UD84NRzUPdl8SecGo5qHuy+JN4gO58VouqLCpKVkTBHGxrI25NaxoDRc3IAGrMla9JoiniLjHBCwvFnYI2txDM4TYark5dKgvnBqOah7sviTzg1HNQ92XxJvEB3PitF1RYUNKxhu1jWmzW8loHJZcMb1C5sOlZlW/nBqOah7sviTzg1HNQ92XxJvED3ufFaLqiyEVb+cGo5qHuy+JPODUc1D3ZfEm8QHc+K0XVFkIq384NRzUPdl8SecGo5qHuy+JN4gO58VouqLIRVv5wajmoe7L4k84NRzUPdl8SbxAdz4rRdUWQirfzg1HNQ92XxJ5wajmoe7L4k3iA7nxWi6osNFXX/X0/Nw92TxL4oO3gVu6sTouqIciIqp9QEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAF9RF4EERFyUj//2Q==",
            Quantity: "5L",
            Pieces: "1",
            Expiry: [21, 10, 2026],
          },
          {
            Name: "Boond Oil",
            Price: "135",
            Image:
              "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUQEhIWFRIVFhUXGBMTFxcWFhcVGBUWFxUVFhYYHSggGBolHRUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGxAQGy0lICUtLS8tLS0tLS0tLy8tLS0tLy8tLy0tLS0tLS0tLS0tLS0tLS0tLS4tLS0tLS0tLS0tLf/AABEIANkA6QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAYBAwUCB//EADsQAAIBAgQEBAMGBAYDAQAAAAECAAMRBBIhMQUGQVETImFxMoGRQlKhscHRFCNi8AcVQ3Ki4TOCklP/xAAaAQEAAgMBAAAAAAAAAAAAAAAAAQMCBAUG/8QAOBEAAQMCAwQJAwIFBQAAAAAAAQACEQMhBBIxQVFxkQUTImGBocHR8DKx4RVCFCMzUvEGcoKi0v/aAAwDAQACEQMRAD8A+4xEQiREQiREQiREQiREQiREQiREQiREQiREQiREQiREQiREQiREQiREQiREQiREQiREQiROJxPiGRyvmO22g1t+95zxxctawPTQuQSDb4RbUgG5lDqzhMMJVgYN6tcSs0cUXUMHOoGzE2Ntpq8ap0qP9TNU9ItBgtKVKeQAzqrXEqtPiFYaFj85n+OrffMn9Spbj5e6rVpiVZuI1ujTK8Wq26fj+8yHSNE7+XtKK0RKx/mlX0+p/eeTxmoNx+Jj9RobSeRRWmJW8NxfMdcwt0vcQ/GWvov/ACMzOOw4E5vI+yhWSJWX4w/YfUz1V4pUI0AB9z+8r/UqG88ipVkiVh+KVAu1m73JkU8Ur6ef8JD+k6DTFzwHuQoJVxiVFuI1iP8AyEe1v2moY2v/APofwlR6Yoj9ruTf/SSrnEqNXiNYixYj1Gn4yGceQbGub9i5vMKvTNJhgNJ5BRmCvUSk/wAa9riqT7Nf9ZdRNrBY5uKzZWkRG7bPsplZiIm8pSIiESIiESIiEXE4rcOMqAsT1Ut0AsLbE9/Se6aGwutj2A279NJo4mlU1rKbL5etvcXBvf8AeZr4a3mBYPcHViQACSR8wbTRqlpBBI14/NVc2ZBCzXokqWA23kPpOvSZQNRZdrE79veQ8Zg1Gqm47XGk5dSkcuYePz5ooqmYUNhNclJSuJrqUrTWMqparTyRNmSPDkXRawJqqU7yTkmMkgyihYfS89qNZKKTxkkXUQo1SSk6TS6SRTXSQi8kXmh0kjLMBZlBRR0tabBJaUwbk2Fhtfr+sPRHhlrW1AEnqjEqFCvNP84UahoIGbxVvoCcuVdgd9bSQq6SM+FUkmxBO5DMPyMUH9S/NfQixg3VVVpcIC94lWzDMgRzTUsoAAB1vLuJ8+ena5Fzfe5LbbbmfQROt0dU6yrVfvy68CFnSENgrMRE6ysSIiESIiESIiEXB4nXYVsqj7tydhM1kYm5O/TYWnri/wAfrYTh80YqtRVMTSa6Dy1KZ1XfRrdNdD8pwcUYrFpNifOfyr6FF1Z4YHX2TYcLKweEWsDfSbCbWUm42ttY+vecvlni9TEU/GakVS9rg323IHUTpYishqinmAZ1vY6H0l7aTsmYam3GVFShUpuLHC4126a6KMosZmqAb95lXBvYg+1vnPY0mkHNNgqdFG8OZFKbiJ6AmIClR/CmPCm/LGWRlukLR4U8mlJOWYtBEaooPhzYqzeQB0MyK1JdXqIo7Fhc+wmLS1xgEc1IaToFqFK824bBFj2G95mpx+ha4dTY2Cqb/lI2K5ppKFYKzEkqFFhrp31m8yhTNySRwP3+HuVrcJXcYDDyj7qTjQt8qDbtNeMBCKp3Pmld5h50ehlFKnTzOL6nMQP6rHec3h2OxWLD1q1Y0aNJSaj01APdUW/U/wB7yKlMlxa0S48AOGpOm8Ad6229E1ur62oWtbvJJ8gCrQxAFyfQTyR6StcGqpWrU0szPTs7MxJPlvoel7lZZXOpnOeS2v1VrNk8SbDlJVGMwYw8AmSe6PfzUStvaXkSjuLNLwJ1+ixBf4eq0mrMRE6yySIiESIiESIiEXF4s4DknsJyywdWpsLo4IIPYzp8cpFmA9JDpUsuk8/j6fWVHN0CzY4tMhSsFxDDUlFHOiZABkPlNrfF63nJ4zZnLaKqrmWtffewJ3uDsJF5r4eHpiuqBqlLUDuovmH6yo0OYiFKMmja26ek2MPjzUZlqgBzbGN/5EEL0GCwXXN6+kZJ1BjX5OoI14rnrimW6gkG5NwSCfpNqcbxK3tXf087HWQcVvfYHUTUbzVcxrvqAPEL1WRrtQD4LqjmfFj/AFm+dj+k2Hm7GD/V/wCK/tOKEJIABJOwAuT7Cd3h3J+LqMM9NkTdmcFbL1OXcn0tMW4em4w1g5D2VFang6QzVWsA7wP8nwlYTm/GnTPr2yL+0YnmfHrozlb7ArlP4iOKcUfDk0MOjYdRp4jDLiX/AKmqEXpg6WVbe/ScWvj61QZXrVHW97O7Pr3Gckj5SThqI0APh6/hYUqFOpDhRYGneBMb4DSP+074U9+Zsaf9dvkbfpI1TjeJbevUP/sw/IyBmi0wGHo/2N5BbjaNJujGj/iPZSTiqh+Ko592J/MyXh6RIBzMToLeva85x2nSwOJqAZFfKpN/S/eXsACipIHZXaoqzMcvlSmPYA2/Ob+G06lasaa6mx1JsBpvOScRl8qknuAdGPUk/tJGDxVYA0qQJaoPMFW5IB2HX8Zth42rmVKTspiNLTs7ytPGMKBXKK3itcDy6gsdALzq85YgYbD0+HpbNpUqldi26r9Rf5CbuWODtQqVMXilyighcA2tnvptpcWOnqJT+I4967uz6s7Fj6E9PkLD5QTkaXRBdYcNvsqWAYnENY05mU4JOwuP0i276uMK2f4eYfyVax3JyA/Rj+JH0loMh8t4TwsLSUjUrnPuwzftOi5FhpY/nOBQ/mPqVd5gcG2HqvN9LVutxTj4crfYKIou4EuolMwjecd7y6T0HRg7Lj3hc0JEROmpSIiESIiESIiEXI4n8fyEh0hc+sl8W+L5CQKZM4mLeBVIKyCnrhvvGfNeM4Whh8S6uPKTmVQLkq2q6nYDUfKfRaT66yrc/cPYinVQXsch9jdgfqD9ZomoG12uA+rsnjq31Hiuz0NWy1jTcYDu+O/8KicQrCo91QIvQA9PnJPD+FjKa9d/CoXsNLvVYfYpD7R7nYdZN4RwinULVapYUaK56rD8Ka/1HacfjHEWr1M7WUAZUpj4adNfhRR+Z6mboAAzO8B82bO8r1Re57uppWj6juB0AnVx1vMC5BMBdBOL1GYUMFT8AOQoyeau1zYZ6w17aLYDuZ2uZKZoLS4dh8zVqhR67gsXdyfKub4rX132tPX+HPD0pipxCtolJWAJ72BdvkNPnOW3OlTxS60KSlmIdsjeIwOlvFzXBtppNhpinLnROkbBtiFzarC/FdXQp5uru6SJc8jshznXIGsb7aARu/xIxStXSmGDVaVJFqMNf5ljoT3tYn3EqJMt/OHLarWofw6EDEC4QkmztYmxPvcyfiuGUuHpSpBUqY6sQuZlDJTBspZUbTQmwvvMKtJ76jiREa/NpKuwWMo0MJSYyXEzA0MgnNM2aAZvJsNt4oN51MNwSs1I1yoSl9+owUE3sApPxG/a8vdbleg2Mo031SnTVSTlU1qigm1gBcBQCxHcDrNeKxPjY7O+VMDgT10p+Iumg2LXsAOw9Zl/DEHtHbA7/wAAa/CsHdNio3+S39pc4nQCYAGhLnGANNRM3Apq8EcVjReyFLs7sfKiL8VRj90afUCWXivLdGl4b+I3hlPEqO65Sq3FrJb4mJsF3J9p5o8Yw9fGD+YFpNU8SrUqWQOKYvTpLm1yDKCb/EfRRIHNPMJxOJHhqWo03BAA+Mq3xEdrXA9yeskMpsYSTN4HzhryVYrY3EVqbQMoyy63ht2yOyDGgJtK7fGsFTGEopTw4SvXceGu9XJa96hH2rWJA0F7dLyRjcOcHh6eHw/mxmIFi43Vd3ZewB2Pz6TRxrH4jE+bD4OshZMniVRYhD8S07Gy36tvaZxPDuJYhBTqGjS8mRnXSoyfdLC9h3AteHYnDtccrhOgi/HTb9lzQKpptbWcAC4lwc6/cCNcotIgE30sVK4jwXJhqGDS+RiKleov2vQN9pmY6ei3MpGMwTtjRSNMU8zqoVRoq3Crr1NhcnrrLvwvAV8KQ2IrGsoXKlyzCnbtfbTr6SZ/CU6jjElPMhGVrWJ0YfTzfhNbFYnMD1Y2WneBA17+aqw3SP8AC1nAnODJkSO06DMGO4RFo7OpJltTsAOmg+QnpUWxzHpoBreG2v0H6yPUftNHDMFGi1m4X47fNcZ5lxKcPo/zAPXS/aW6V7hCHOS2thp7bSwzvYBsU53lYpERN1EiIhEiIhEiIhFxeL/Hb0EiUxNnMFcI4Y7AGRuG4taoLKLAGwv6AfvOHjGg1jvWQKlU11kPmrDFsLVXeyFh7qM36TpUxPGNpZkYHYqR9Rac7GMLaLnt1bB5EFbGHqGnVa4bDPJfPOIoKfCqQX/Xqs7EdQt1UfgJVsFhHq1FpUx5mIAHqf0nawvHEFA4SvRL01YsjI4R1J0I8wsRea/89WkCuEpeExFjVZhUrAdlNgqfITqPDSRe0Ad/zdsXtqRrUesa1hLi9xBtlg6EmZsIkATbTar5hUwzMnCg10pJnqZTbxHBH8sW1OpLEDsBKriOXqRxTVWQ4XBIwN610zBdxTVtTc7ekp5exvfXfc797739Z0+HcBxeKIKIx/rYsLf+5/SS/EMcBmbpp7f41VFPo+phc1QV4BFy7TMdXagTum43FdPmHm0VsXTrIpFGgy5FPlJAcEkjpfKAB23kjinNdJ65xVGlUauVVUNYLlo2GjKikmo+p7CTMLyLQpANjK3UDJSB1J2A0LE+wnd4WcLRqCnSwuVc60/FOUtnamKi362I0v3kipWcSYFzN7chrI3EBcyvi+jaQa2kHOygtsYBBMkEm5m85dZMWMKm8J4ZxSpWXEp4gqbirWJAAO48/Q3OgFp3sby5UcZsdjFCAs3h0gFQMAWc2CgFrAm9iZNL4yq7UnBdFfMwBNJGVSy+EGyKdQyt8TA+GbkXkily1mUGoxV2StTbKSxyVNEux3dFsue1yLiVltQiC8+Fh6nzWjW6YqPcHU2NZGhDQSOBIgeAGpXHp4PhtAoBTasHVHFRmUplZ8ma2YbEeaw8o3kylxkijehQpU6viIi0gMx+PK4IWzG1iLgW952afLuGH2CfiNmZyPNlz3BOuYqCQdyLzpUsOqklVUE6kgAEnubbyk0GbRJ77rRq4utV/qPJ4lV3C8Qxr1lbwm8A1FurKFemjUyGVr6OFqA6qdrHUEWYnhmKLMFZrl3bxDVOQrq1FfD+yVYIDYWsDqbyzWmbRkWvK4fD8NWVDRcLkGcK4dmbKWOQMCo2BAvc3tPNQVfgIA/qvp7gbzsvPNcm1j1EwdSnVQbrnlxsNgJoLiS2FtpqZBcNbT9ZgKZUSp3Ax+U78r3CqvmyywzvYQAUhChIiJsqUiIhEiIhEiIhFVOcwbadBr7Sq8J4y1E5GF0vf+oX6jvL1xtb5h/T+k+e4JUDs9YE2+z3N9j6ThY/sVcw2qIOxX/A4hXUOpup6ie8S4Ck9gTInCkLUxUsq5tlHbpPXFaFR6L00sHYFQTsL6E/Qmc7FZjRcyNRHO3ryWxSALxJi+q+L1Tdm9WP4mdrg/KOIxFjl8OmftPdfou5l94Ryth8OAbZ3+842/2r0neBm1nk7h8+bV6bGf6ggkYYeJ9B78lT6PA8BghnrHxaqqzhXyljlUsclO/YHftJn+ZV6rLSpWpI9J2Ura4IJGrEWIGamRlFjc+YgaycXwFXxBrl2AITyqbedcykkHQgoxXUe1p0MDgqdFclNQo07kmwsLsdToOsubUaz6RfevN18RVruzVXFx7/AE3eCrmG5Zq1PNWqsA2Y+G1qhUs6VVsxvbK6kZTmFvciWDC8KpIwfLmqAWztYtYXtawAG5GgGmkmXmLyDWJVBC93iebzBMdaUherzN5rJmQZHWJC2ReeLzOaYGokLwzazxXOgPeIxSG1+2kyzkqFGMzUUFDYagg/I6H9J4Vte881aw6b+m1piHoVnAGzj5y1Ss4RwWU/a6+um8s06uA/pnj6BQkRE3kSIiESIiESIiEXH4jY1CO4lI45gbsVBAvrLpxd7OD7fjKNzCagrEk+UWHtpOT0k3M0RqD6KJhW3hF0pogN1Cix9hvOgal5X+UqtR1KuMqDVXYaH09Z3jTud1C+hmm1hLZUgrBmJ5Lam3eZBmKzWZmYvMgzKyLMTF55zRZQszJMjVsdTXdtew1kCvxi2y29SZTUr0mfU71PksS4Bda8FpWK/Gz9/wCSyL/Gu2yM3qbyh2LH7WnxgfdRmJ0CtzYlRuw+s1tjqY+2PxlYVa5+yq+8y2GqHeoolX8YT/bPEn7Ke0rNh8YhNr3PbWTMZi6aKQzC5FpVeH4dvEX+bfUTbxvCWY/zGAPp+E26eId1ZdHk72SHyp3iq2isCT06yNcHYicqjgySAtVix/sTfxHBNnYh7bbDS4AufmbmYNqOLZy+TvZMr9y7PDaRzjqJbJROACp4gOcMpB7g/Qy9zvdH/wBLx9AiRETeRIiIRIiIRIiIRcLjlcIWY/ZW/wCE+c18Y1RizjeXDnbEWYJ962vpKjhcUmcLVFhe19vnOH0g9xq5QLBYuhWflPEZkNM65Dp/tP8AZlhqpl1IkPgXCkQNWQ6EDTpp1vGKxBY+0pcMjAXanRS3RPEnoNI4MxVrhdzaaxfF1mCpOaGrAak2E4+J4rbbQdz+05dTHM5soLH8JScSP23+yxzzou/iOLAaKL+p0E5GL4sToWJ/pXaRjhif/K4H9AM21qtOjTZxYZVJud9BNU1alWwJPcLDnt81IpPdqvCrWbYBB3O8x/BoD52Z27C/9gTPCxXqUl8UqtUqCco8oY9AJC4Ph61FqgxFQPVdrgqLAINFAB+fzMtbhHAXIH+33VzKAC7VPDBdkA/OYxfmpsFcqxUgMLXU20OvaZTFCcDi2ExdY1Ew9SnTDAAMwYkEjzWttLm4akHCwPGSrRTaNiicrYzG1qAqVgpOoDZiCwBtmy2sL2nM4rxzEpjKOHqUxTpPUW7Kc2db7Xtp0vLHwAGhRp4eoAHpoqkA3FwLXB6g2vIfNdZA1BtPE8Vco6nQ5rfK83qQZnJAA1tuUmQIVqWuLAjfoRObzdXeslNKL5WzAuwtdVXXW/c6fWeMXwYlT4dRkzqGW50W+ttZIwmCFMFQAWOrNe4J995LqmQS4gfNd33WJUXgmKen8b5nBPmAy6X00v2ljrAlb2zK6hgx3uPiH5zj0OFIagqZSWF7am3zGx+ctzhDTUdV1t021tKqFc1GuDDpt9t9lW986Lm8KoWym2n97y2yuUF8w95Y51+jmltMg7/QKkpERN9QkREIkREIkREIqPzrTzVexAUDtrf9pE4TSzKgKgtoNQCd7SfzM6HEENqQF06bdpzmx607kHXp0tPO4qq01nTsKxJVlxmKyAUlYWC622ve85dXGKOuvYSvPxJn0QFvbQfWaqiEDNUqBF7D95pYjFl7reGpt3AXUtDjourieLAdbe2pkLxar6qth95py+LcVTDUjUpoHfQKrG7MSdABqbzxheJ4qrSzvSNFtdHF7DobCUdRUqNznTv9Gj1VraN7qVUxuGSp4b1TUqi10QFst+rAbD3nQbilJStNSAzaKgtc/Ka+B4KnSS4s1R/M9Q2zOx3JPboBI/FK9Km64hlBKXNwLkAggkfWbYwVMAF0u4+g05yr2saF6blek1cYt2qeNa3lcgAdrdfnObzTwJnAAxDrTBBKALckG4ubai/Sdajx6lUUPTqKy9wR/YkbH1atRf5Sqx7s2Vbe4Bm09wBAbqLDu4LMLZR48qgK7BTsMxAv7Tn81NiK6U3wYzVVe+YEBQtiGBJNjfTSU7mCjjRWpvVoB6aOCFo3qXt30vf3An0Xg+I/lqQjILfC4ykfKQC2nlzkabYjgdFBcLrh8M/zE6YhKdIAjzL5ifaxsJYaWJWmAL/M7kyU7k/9yBg+EIpJJaoxJ1qa2HYAaTUqYvD03S2/DTn+ViaohRBhaeJr+Nma9JSnlYhSSb2NvitI2I5Op1MTTxLVHsjBvDJLA22AufLrbaWrD4KwsAFHZf2El08Oo9feUDE4h57Ay951+eCrc8lKWGRgMpN/Xb6yT/AoOub8BCmeg0vZhmuOapc+Puq17RQNtJJoagjqB+HWULnPmSpScUKRytoWbqCdgJzeCc44ikDc+L/v1y39RqQdp0aTWthdKn0TiKtEVWxfQTeN+7zX01AM+ksEp/AuKJiFDro2mZPuk7jXcS4Tp4X6Sua9jmOLXCCEiImysEiIhEiIhEiIhF805vY/xtRXpeTJTK1B1NvMpsbi05fDqdOoWIynKbb5je19e3SW/mLhGIqVmemispCgEsBqBrpOUvKOJBLKlMFrZipAJttfvPOVsPUfXeTTJEm4Ot9bn5uVzXtiCFDrowFlYD0t+042DWo7kYki4JyovwFeja6k++0uDcp17A3UntNdXk2sTfyEja52knC1WfRSMeHusxWaqnxTBUw64mmq+LTuR0BFtQfl1krhvMK1qYfI6XHwupB/795YF5Nr9cn1/wCpMwvJzA+dgR2BkihiTbq44keidcFQWxtZqwWiLUbHPnUizdMh09b9JIGCNQFavmU9BcC3qRL3jOUOtIi/ZibfWRV5UxG10t3v/wBSqthsY3stZ4g284+yjrZXzYckYday1EZlCkEpfMpt011t6S30rgWA09RadxeUK33k+p/aSaXKlTrUHyvMH4bpGprPiQFjI3rhJhz7TLUwNzLJV5YNvLU19ZzcTyxiCLLk9yb/ALTW/RsUD2o8LoCwrlK/YTfTxJHtPS8q4waZl0O9xcj673m4cr4sbEXt9ora/fSbFPo57bFpnfB9lmQ0aOHn7LNPEX6zctS8xh+XMSPiC/Jh9TJY4JiB0X/6Etbgqw/aVW6FrVxNgM0YjheLA8lME986Afj+010+EY4gZgAbagFd+1wZeKFUfsPJYmYn1Cp3O+EptWzBmVwBmNiUvrYEgaG04+AwDsT4Do7WsUQ626nzAX/SfSRwDEndF9i2/ofMZs4HymKDPUCAM5PUHKPur87yynSqk3aQuxh+l+roZCDLRaYIPjAI5k7JUTlHhTUVzPcPUy3Xe1v11l/nBxeBrZG8NRnscvmHxW0303ncXYX3nUoNyiFya1V1Z5e7Ur1ERLlUkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIkREIv//Z",
            Quantity: "1L",
            Pieces: "10",
            Expiry: [25, 9, 2024],
          },
        ],
      },
    },

    {
      Name: "Ashoka Dealers and Suppliers",
      Item: {
        EdibleOil: [
          {
            Name: "Fortune Oil",
            Price: "97",
            Image:
              "https://www.bigbasket.com/media/uploads/p/l/272765_9-fortune-soya-bean-oil.jpg",
            Expiry: [25, 9, 2028],
          },
          {
            Name: "Prestige Oil",
            Price: "625",
            Image: "https://m.media-amazon.com/images/I/61m8vWwgieL.jpg",
            Quantity: "5L",
            Pieces: "1",
            Expiry: [23, 11, 2023],
          },
        ],
      },
    },
  ];
  return (
    <div>
      <SearchRes>Search results for- "EDIBLE OIL"</SearchRes>
      <div className="InsideContainer">
        <ItemGroup>
          {data.map((ele) => {
            return ele.Item.EdibleOil.map((temp, index) => (
              <Item className="Item">
                <LeftGroup>
                  <Image>
                    <img src={temp.Image} alt="" />
                  </Image>
                  <Information>
                    <div>Name: {temp.Name}</div>
                    <div>Price: {temp.Price}</div>
                    <div>Quantity: {temp.Quantity}</div>
                    <div>Pieces: {temp.Pieces}</div>
                    <div>
                      Expiry: {temp.Expiry[0]}-{temp.Expiry[1]}-{temp.Expiry[2]}
                    </div>
                  </Information>
                </LeftGroup>
                <ButtonGroup>
                  <Counter initialValue={0} />
                </ButtonGroup>
              </Item>
            ));
          })}
        </ItemGroup>
        <a href="/addToCart">
          <CompleteOrderButton>GO TO CART</CompleteOrderButton>
        </a>
      </div>
    </div>
  );
}

export default ItemBank;
const Item = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
`;
const SearchRes = styled.div`
  font-size: 30px;
  margin-left: 80px;
  font-weight: 600;
  margin-top: 20px;
  color: #05386b;
`;
const LeftGroup = styled.div`
  display: flex;
  justify-content: space-between;
  width: 250px;
  font-size: 16px;
  line-height: 23px;
  font-weight: 500;
`;
const ButtonGroup = styled.div``;
const Information = styled.div``;
const Image = styled.div`
  img {
    height: 100px;
    width: 100px;
  }
`;
const ItemGroup = styled.div`
  margin-left: 120px;
  display: grid;
  grid-gap: 30px;
  grid-template-columns: 600px 600px;
  margin-top: 40px;
`;

const CompleteOrderButton = styled.div`
  margin-left: 70px;
  margin-top: 30px;
  margin-bottom: 40px;
  padding: 15px;
  background-color: #edf5e1;
  border-radius: 10px;
  transition: 300ms;
  cursor: pointer;
  color: #05386b;
  a {
    text-decoration: none;
  }
  &:hover {
    background-color: #379683;
    transform: scale(1.1);
  }
`;
