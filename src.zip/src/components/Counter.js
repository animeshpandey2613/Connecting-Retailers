import React, { useEffect, useState } from "react";
import "./Counter.css";
function Counter({ initialValue }) {
  const [counting, setCount] = useState(initialValue);

  const handleIncrement = () => {
    setCount(counting + 1);
  };

  const handleDecrement = () => {
    if (counting > 0) {
      setCount(counting - 1);
    }
  };

  return (
    <div>
      <div className="container">
        <p className="heading">Add To Cart</p>
        <p className="counter" id="counter">
          {counting}
        </p>
        <button className="incr" onClick={handleIncrement}>
          <i className="fas">+</i>
        </button>
        <button className="decr" onClick={handleDecrement}>
          <i className="fas">-</i>
        </button>
      </div>
    </div>
  );
}

export default Counter;
