import React from "react";
import logo from "../images/logo.png";
import "./NavBar.css";
function Navbar() {
  return (
    <div class="header">
      <nav class="nav">
        <img
          src={logo}
          alt="Bankist logo"
          class="nav__logo"
          id="logo"
          designer="Utkarsh"
          data-version-number="3.0"
        />
        <ul class="nav__links">
          <li class="nav__item">
            <a class="nav__link" href="/AboutUs">
              About Us
            </a>
          </li>
          <li class="nav__item">
            <a class="nav__link" href="#section--1">
              My Items
            </a>
          </li>
          <li class="nav__item">
            <a class="nav__link" href="/shop">
              Shop
            </a>
          </li>
          <li class="nav__item">
            <a class="nav__link" href="/MyOrders">
              My Orders
            </a>
          </li>
          <li class="nav__item">
            <a class="nav__link nav__link--btn btn--show-modal" href="/">
              LOGIN
            </a>
          </li>
        </ul>
      </nav>
    </div>
  );
}

export default Navbar;
