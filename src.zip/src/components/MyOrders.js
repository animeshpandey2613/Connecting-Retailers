import React, { useState, useEffect } from "react";
import "./MyOrders.css";
import Navbar from "./Navbar";
function MyOrders() {
  const [selectedFilters, setSelectedFilters] = useState(["all"]);
  const [orders, setOrders] = useState([
    {
      id: 1,
      name: "Edible Oil",
      status: "onway",
      price: 1242,
      date: "2023-08-16",
    },
    {
      id: 2,
      name: "Surf Excel",
      status: "delivered",
      price: 100,
      date: "2023-08-05",
    },
    {
      id: 3,
      name: "Chocolate",
      status: "cancelled",
      price: 500,
      date: "2023-07-28",
    },
    // Add more orders here
  ]);
  const [filteredOrders, setFilteredOrders] = useState(orders);

  useEffect(() => {
    const newFilteredOrders = orders.filter(
      (order) =>
        selectedFilters.includes("all") ||
        selectedFilters.includes(order.status)
    );
    setFilteredOrders(newFilteredOrders);
  }, [selectedFilters, orders]);

  const handleFilterChange = (event) => {
    const filterValue = event.target.getAttribute("data-filter");
    if (selectedFilters.includes(filterValue)) {
      setSelectedFilters(
        selectedFilters.filter((filter) => filter !== filterValue)
      );
    } else {
      setSelectedFilters([...selectedFilters, filterValue]);
    }
  };

  return (
    <div>
      <Navbar />
      <div className="eksath">
        <div className="sidebar">
          <h2>Filters</h2>
          <ul className="ul">
            <li className="li">
              <label>
                <input
                  type="checkbox"
                  data-filter="all"
                  checked={selectedFilters.includes("all")}
                  onChange={handleFilterChange}
                />
                All Orders
              </label>
            </li>
            {/* Add other filter checkboxes here */}
          </ul>
        </div>
        <div className="main-contents">
          <h1>My Orders</h1>
          <div className="order-list">
            <a href="/OrderConfirm" style={{ textDecoration: "none" }}>
              {filteredOrders.map((order) => (
                <div className="order-card" key={order.id}>
                  <p className="order-name">Product: {order.name}</p>
                  <p className="order-status">Status: {order.status}</p>
                  <p className="order-date">Date: {order.date}</p>
                  <p className="order-price">
                    Price: Rs {order.price.toFixed(2)}
                  </p>
                  <div className="order-actions">
                    <button className="cancel-button">Cancel</button>
                    <button className="reorder-button">Reorder</button>
                  </div>
                </div>
              ))}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MyOrders;
