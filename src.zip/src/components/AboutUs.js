import React from "react";
import "./AboutUs.css";
import Navbar from "./Navbar";
import animesh from "../images/animesh_img2.jpg";
import poorty from "../images/poorty_img.jpg";
import utkarsh from "../images/utkarsh_img.jpg";
import rishi from "../images/rishi_img2.jpg";
function AboutUs() {
  return (
    <>
      <Navbar />
      <div className="Contains">
        <div className="section">
          <br />
          <h2 className="h2">About Retail Roaster</h2>
          <div className="overview">
            <span style={{ fontWeight: "bold", color: "#05386b" }}>
              {" "}
              Welcome to Retail Roaster{" "}
            </span>
            , where we are committed to revolutionizing the retail industry by
            addressing and alleviating the{" "}
            <span style={{ fontWeight: "bold", color: "red" }}>
              challenges faced by retailers.
            </span>{" "}
            With a deep understanding of the ever-evolving landscape of retail,
            we have developed a range of
            <span style={{ fontWeight: "bold", color: "#05386b" }}>
              {" "}
              innovative solutions
            </span>{" "}
            that are designed to transform the way retailers operate and thrive
            in today's competitive market.
          </div>
          <br />
          <br />

          <h3 className="h3">Our Mission</h3>
          <div className="mission">
            <span style={{ fontWeight: "bold", color: "#05386b" }}>
              Our Mission
            </span>{" "}
            is clear: we aim to provide retailers with cutting-edge tools,
            insights, and strategies that streamline their operations and lead
            to{" "}
            <span style={{ fontWeight: "bold", color: "#05386b" }}>
              sustainable growth.
            </span>{" "}
            We understand that every retailer is unique, with their own set of
            obstacles to overcome. That's why we've assembled a team of experts
            with diverse backgrounds in retail, technology, and business
            development. Our mission is to create tailor-made solutions that
            cater to the specific needs of each retailer, addressing their pain
            points and{" "}
            <span style={{ fontWeight: "bold", color: "#05386b" }}>
              enhancing their strengths.
            </span>
          </div>
          <br />
          <h3 className="h3">Our Team </h3>
          <div>
            <div class="team">
              <div class="imageGroup">
                <img class="image" src={rishi} />
                <p>Rishi Dubey</p>
              </div>
              <div class="imageGroup">
                <img class="image" src={utkarsh} />
                <p>Utkarsh Shrivastava</p>
              </div>

              <div class="imageGroup">
                <img class="image" src={animesh} />
                <p>Animesh Pandey</p>
              </div>

              <div class="imageGroup">
                <img class="image" src={poorty} />
                <p>Poorty Jain</p>
              </div>
            </div>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />

            <div class="icons">
              <div class="div1">
                <div class="first">
                  <a href="#" class="fa fa-youtube"></a>
                </div>
                <div class="second">
                  <a href="#">youtube.com/retailRoasterpvtltd</a>
                </div>
              </div>
              <div class="div1">
                <div class="first">
                  <a href="#" class="fa fa-facebook"></a>
                </div>
                <div class="second">
                  <a href="#">facebook.com/retailRoasterpvtltd</a>
                </div>
              </div>
              <div class="div1">
                <div class="first">
                  <a href="#" class="fa fa-instagram"></a>
                </div>
                <div class="second">
                  <a href="#">instagram.com/retailRoasterpvtltd</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AboutUs;
