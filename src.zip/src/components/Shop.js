import React from "react";
import NavBar from "./Navbar";
import Form from "./Form";
function Shop() {
  return (
    <div>
      <NavBar />
      <Form />
    </div>
  );
}

export default Shop;
