import React from "react";
import "./CoverPage.css";
import logo from "../images/logo.png";
function CoverPage() {
  return (
    <>
      <div className="Container">
        <div>
          <img className="logos" src={logo} />
        </div>
      </div>
    </>
  );
}

export default CoverPage;
