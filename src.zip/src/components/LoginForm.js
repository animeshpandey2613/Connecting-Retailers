import React from "react";
import "./Login.css";

function Login() {
  return (
    <>
      <div class="outer-container">
        <div class="inner-container">
          <h1 class="signin">Sign In</h1>
          <input type="text" placeholder="Email" class="name" />
          <input type="password" placeholder="Password" class="email" />
          <div class="terms">I read and agree to Terms & Conditions</div>
          <div class="account">
            <a href="/AboutUs">
              <button type="submit" class="btn btn-primary btn-ghost">
                LOGIN
              </button>
            </a>
          </div>
          <div class="signup">
            Don't Have A Account Yet?
            <a href="https://www.ietdavv.edu.in" class="styled-link">
              Sign Up
            </a>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
